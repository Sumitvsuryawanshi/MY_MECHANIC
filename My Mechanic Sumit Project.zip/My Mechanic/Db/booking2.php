
<?php

    session_start();
          $conn = mysqli_connect("localhost", "root", "","user") or die(mysqli_connect_error());

            if($_SESSION['email']){
              if($_SERVER['REQUEST_METHOD']=="POST")
              {


                  $namef=mysqli_real_escape_string($conn,$_POST['namef']);
                  $contactf=mysqli_real_escape_string($conn,$_POST['contactf']);
                  $emailf=mysqli_real_escape_string($conn,$_POST['emailf']);
                  $servicef=mysqli_real_escape_string($conn,$_POST['servicef']);
                  $service_datef=mysqli_real_escape_string($conn,$_POST['service_datef']);
                  // $la=mysqli_real_escape_string($conn,$_POST['latitude']);
                  // $lg=mysqli_real_escape_string($conn,$_POST['longitude']);
                  $timef=mysqli_real_escape_string($conn,$_POST['timef']);
                  $location_longitudef=mysqli_real_escape_string($conn,$_POST['location_longitudef']);
                  $location_latitudef=mysqli_real_escape_string($conn,$_POST['location_latitudef']);

                  mysqli_query($conn,"INSERT INTO four_wheeler(namef,contactf, emailf,servicef,service_datef,location_latitudef,location_longitudef,timef)  VALUES ('$namef','$contactf','$emailf','$servicef','$service_datef',' $location_latitudef','$location_longitudef','$timef')");

                  // mysqli_query($conn,"UPDATE four_wheeler SET namef='$namef' ,contactf='$contact_nof',emailf='$emailf',servicef='$servicef',service_datef='$service_datef', timef ='$timef' WHERE namef=0");
                  //
                  // mysqli_query($conn,"DELETE FROM four_wheeler WHERE location_latitudef=0");
                  // Print '<script>alert("Succesfully Added New");window.location.assign("alogin.php");</script>';

              }

              if(isset($_POST['subm'])){
                $l1 =$_POST['location_latitudef'];
                $l2 =$_POST['location_longitudef'];
                $l3 =$_POST['namef'];
                header("Location: nearest1.php?/&ntd=$l3&lat=$l1&long=$l2");
              }
            }
            else{
                  Print '<script>alert("Login to continue...");window.location.assign("index.php");</script>';
                // header("location:index.php");
            }

?>
