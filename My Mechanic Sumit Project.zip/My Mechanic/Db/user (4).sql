-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2022 at 06:03 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(20) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `admin_pass` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `admin_name`, `admin_pass`) VALUES
(1, 'raj', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `four_wheeler`
--

CREATE TABLE `four_wheeler` (
  `id` int(11) NOT NULL,
  `namef` text NOT NULL,
  `contactf` varchar(10) NOT NULL,
  `emailf` text NOT NULL,
  `servicef` text NOT NULL,
  `service_datef` date NOT NULL,
  `location_latitudef` double NOT NULL,
  `location_longitudef` double NOT NULL,
  `timef` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `four_wheeler`
--

INSERT INTO `four_wheeler` (`id`, `namef`, `contactf`, `emailf`, `servicef`, `service_datef`, `location_latitudef`, `location_longitudef`, `timef`) VALUES
(1, 'Rajvardhan', '987654321', 'shinderajvardhan17@gmail.com', 'Diagnostic test', '2022-12-10', 73.8567437, 18.5204303, '03-05'),
(4, 'Rajvardhan Shinde', '90909090', 'shinderajvardhan17@gmail.com', 'Vaccum Cleaning', '2022-12-10', 79.0881546, 21.1458004, '03-05'),
(5, 'Rajvardhan Shinde', '987654321', 'shinderajvardhan17@gmail.com', 'Tires Replacement', '2022-12-10', 0, 0, '03-05'),
(6, 'Rajvardhan Shinde', '987654321', 'shinderajvardhan17@gmail.com', 'Vaccum Cleaning', '2022-12-10', 21.1458004, 79.0881546, '09-01'),
(7, 'Rajvardhan Shinde', '987654321', 'shinderajvardhan17@gmail.com', 'Headlight Repearing', '2022-12-10', 16.9417714, 74.4185732, '03-05'),
(8, 'Shinde', '90909090', 'shinderajvardhan17@gmail.com', 'Tires Replacement', '2022-12-09', 16.9417719, 74.4185737, '12-02'),
(9, 'Shinde', '90909090', 'shinderajvardhan17@gmail.com', 'Tires Replacement', '2022-12-09', 21.1458004, 79.0881546, '12-02'),
(10, 'Rajvardhan', '987654321', 'shinderajvardhan17@gmail.com', 'Engine Servicing', '2022-12-10', 21.1458004, 79.0881546, '03-05'),
(11, 'cdcddccd', '987654321', 'shinderajvardhan17@gmail.com', 'Engine Servicing', '2022-12-10', 16.9417775, 74.4185761, '12-02'),
(12, 'rohan', '987654321', 'shinderajvardhan17@gmail.com', 'Tires Replacement', '2022-12-25', 16.9417722, 74.418575, '12-02'),
(13, 'Rajvardhan Shinde', '987654321', 'shinderajvardhan17@gmail.com', 'Diagnostic test', '2022-12-10', 16.9315599, 74.4173763, '09-01'),
(14, 'Rajvardhan Shinde vvvvvv', '123456', 'shinderajvardhan17@gmail.com', 'Oil Changing', '2022-12-09', 16.9315599, 74.4173763, '09-01'),
(15, 'Rajvardhan Shinde', '987654321', 'shinderajvardhan17@gmail.com', 'Diagnostic test', '2022-12-10', 16.9417738, 74.4185752, '09-01'),
(16, 'Rajvardhan Shinde', '987654321', 'shinderajvardhan17@gmail.com', 'Diagnostic test', '2022-12-10', 16.9315599, 74.4173763, '12-02'),
(17, 'Shinde', '98765431', 'shinderajvardhan17@gmail.com', 'Vaccum Cleaning', '2022-12-10', 16.9315599, 74.4173763, '12-02'),
(18, 'Rajvardhan Shinde', '987654321', 'shinderajvardhan17@gmail.com', 'Engine Servicing', '2022-12-10', 16.9315599, 74.4173763, '09-01'),
(19, 'Rajvardhan Shinde', '987654321', 'shinderajvardhan17@gmail.com', 'Oil Changing', '2022-12-10', 16.9315599, 74.4173763, '12-02'),
(20, 'Rajvardhan Shinde', '987654321', 'shinderajvardhan17@gmail.com', 'Diagnostic test', '2022-12-10', 16.9315599, 74.4173763, '09-01'),
(25, 'Rohan Sutar ', '2147483647', 'shinderajvardhan17@gmail.com', 'Diagnostic test', '2022-12-10', 16.941772, 74.418575, '09-01'),
(26, 'Rohan ', '98747834', 'rohan@gmail.com', 'Diagnostic test', '2022-12-10', 16.9315599, 74.4173763, '09-01'),
(27, 'Rohan Sutar ', '9370160832', 'rohan@gmail.com', 'Vaccum Cleaning', '2022-12-10', 16.941772, 74.418575, '09-01'),
(28, 'Bhushan Salavi', '9503939462', 'bhushansalavi33@gmail.com', 'Engine Servicing', '2022-12-10', 16.9315599, 74.4173763, '09-01'),
(29, 'Abhijeet', '7588552640', 'salunke@gmail.com', 'Oil Changing', '2022-12-11', 19.3449, 74.6763, '03-05');

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pass` varchar(10) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `city` text NOT NULL,
  `phone` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`id`, `name`, `email`, `pass`, `latitude`, `longitude`, `city`, `phone`) VALUES
(3, 'Lava Center', 'lava@gmail.com', '1234', 16.8524, 74.5815, 'Sangli', '9658742392'),
(4, 'TVS Services', 'tvs@gmail.com', '1234', 17.6805, 74.0183, 'Satara', '8542682100'),
(17, 'Sharad Pawar', 'shaeadpawar@gmail.com', '1234', 16.9315599, 0, 'Baramati', '975986741'),
(18, 'Ratan Tata', 'ratan@gmail.com', '1234', 16.9315599, 74.4173763, 'Maharashtra', '976598674'),
(20, 'Samrudhi Services', 'samrudhi@gmail.com', '1234', 26.2554, 88.2009, 'Isalampur', '7785664258');

-- --------------------------------------------------------

--
-- Table structure for table `service_center`
--

CREATE TABLE `service_center` (
  `cust_name` text NOT NULL,
  `service_req` text NOT NULL,
  `lat` double NOT NULL,
  `longi` double NOT NULL,
  `contact` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `service_centerf`
--

CREATE TABLE `service_centerf` (
  `cust_namef` int(11) NOT NULL,
  `service_reqf` int(11) NOT NULL,
  `longif` int(11) NOT NULL,
  `latf` int(11) NOT NULL,
  `contactf` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `two_wheeler`
--

CREATE TABLE `two_wheeler` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `contact_no` varchar(10) NOT NULL,
  `email` text NOT NULL,
  `service` text NOT NULL,
  `service_date` date NOT NULL,
  `location_latitude` double NOT NULL,
  `location_longitude` double NOT NULL,
  `timet` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `two_wheeler`
--

INSERT INTO `two_wheeler` (`id`, `name`, `contact_no`, `email`, `service`, `service_date`, `location_latitude`, `location_longitude`, `timet`) VALUES
(44, 'Rajvardhan Shinde', '98765432', 'shinderajvardhan17@gmail.com', 'Engine Servicing', '2022-12-10', 16.9315599, 74.4173763, '09-01'),
(45, 'pavan', '7412396', 'pavan@gmail.com', 'Break Fluid Exchange', '2023-01-05', 16.9315599, 74.4173763, '12-02'),
(46, 'Rohan', '741236985', 'rohan@gmail.com', 'Wheel Alignment', '2022-12-31', 16.9315599, 74.4173763, '03-05'),
(47, 'Abhijeet', '7896321', 'abhi@gmail.com', 'Oil Changing', '2022-12-20', 16.9417744, 74.4185745, '12-02'),
(48, 'Sonya ', '852456852', 'sonya@gmail.com', 'Battery Servicing', '2022-12-30', 16.9417743, 74.418578, '12-02'),
(53, 'Rajvardhan Shinde', '98765', 'shinderajvardhan17@gmail.com', 'Battery Servicing', '2022-12-10', 16.9315599, 74.4173763, '12-02'),
(54, 'Rajvardhan Shinde', '987654321', 'shinderajvardhan17@gmail.com', 'Engine Servicing', '2022-12-10', 16.9315599, 74.4173763, '09-01'),
(55, 'rrrr', '987654321', 'shinderajvardhan17@gmail.com', 'Battery Servicing', '2022-12-10', 16.9417752, 74.4185746, '09-01'),
(56, 'Rajvardhan Shinde', '987654321', 'shinderajvardhan17@gmail.com', 'Battery Servicing', '2022-12-10', 16.9315599, 74.4173763, '09-01'),
(57, 'Rajvardhan Shinde', '987654321', 'shinderajvardhan17@gmail.com', 'Battery Servicing', '2022-12-09', 16.9417783, 74.4185744, '09-01'),
(58, 'Rajvardhan Shinde', '987654321', 'shinderajvardhan17@gmail.com', 'Wheel Alignment', '2022-12-10', 16.9417783, 74.4185744, '03-05'),
(62, 'abhiriya', '9397495934', 'abhiriya@gmail.com', 'Battery Servicing', '2022-12-10', 16.9417707, 74.418578, '12-02'),
(63, 'bhushan', '7412369852', 'salvibhushan33@gmail.com', 'Tires Replacement', '2022-12-21', 16.9417745, 74.4185782, '12-02'),
(64, 'Abhijeet', '952039655', 'abhijeet@gmail.com', 'Engine Servicing', '2022-12-11', 16.9315599, 74.4173763, '09-01'),
(65, 'Abhijeet', '9503939462', 'abhijeet@gmail.com', 'Tires Replacement', '2022-12-11', 16.941498, 74.417786, '12-02');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(20) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_pass` varchar(50) NOT NULL,
  `user_email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `user_pass`, `user_email`) VALUES
(0, 'raj', '1234', 'shinderajvardhan17@gmail.com'),
(1, 'raj', '1234', 's@gmail.com'),
(0, 'rohan', '123', 'rohan@gmail.com'),
(0, 'abhi', '1234', 'abhi@gmail.com'),
(0, 'xyz', 'asdf', 'email4@gmail.com'),
(0, 'ro', 'rohan', 'ro@gmail.com'),
(0, 'shinde', '1234', 'sh@gmail.com'),
(0, 'my', 'abc', 'mevh@gmail.com'),
(0, 'Raj', 'lkklj', 'rajvardhanshinde45@gmail.com'),
(0, 'Rohit', '1234', 'rohit@gmail.com'),
(0, 'Rajvardhan Shinde', '1234', 'emai4@gmail.com'),
(0, 'Rajvardhan Shinde', '1234', 'shinde123@gmail.com'),
(0, 'abs', '1234', 'abs_cse@adcet.in');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `four_wheeler`
--
ALTER TABLE `four_wheeler`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `two_wheeler`
--
ALTER TABLE `two_wheeler`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `four_wheeler`
--
ALTER TABLE `four_wheeler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `two_wheeler`
--
ALTER TABLE `two_wheeler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
