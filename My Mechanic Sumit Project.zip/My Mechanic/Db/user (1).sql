-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 07, 2022 at 05:03 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(20) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `admin_pass` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `admin_name`, `admin_pass`) VALUES
(1, 'raj', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `four_wheeler`
--

CREATE TABLE `four_wheeler` (
  `namef` text NOT NULL,
  `contactf` int(11) NOT NULL,
  `emailf` text NOT NULL,
  `servicef` text NOT NULL,
  `service_datef` date NOT NULL,
  `location_latitudef` double NOT NULL,
  `location_longitudef` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `four_wheeler`
--

INSERT INTO `four_wheeler` (`namef`, `contactf`, `emailf`, `servicef`, `service_datef`, `location_latitudef`, `location_longitudef`) VALUES
('Rajvardhan Shinde', 151202020, 'shinderajvardhan17@gmail.com', 'engine', '2023-05-05', 626125, 5151515);

-- --------------------------------------------------------

--
-- Table structure for table `service_center`
--

CREATE TABLE `service_center` (
  `cust_name` text NOT NULL,
  `service_req` text NOT NULL,
  `lat` double NOT NULL,
  `longi` double NOT NULL,
  `contact` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `service_centerf`
--

CREATE TABLE `service_centerf` (
  `cust_namef` int(11) NOT NULL,
  `service_reqf` int(11) NOT NULL,
  `longif` int(11) NOT NULL,
  `latf` int(11) NOT NULL,
  `contactf` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `two_wheeler`
--

CREATE TABLE `two_wheeler` (
  `name` text NOT NULL,
  `contact_no` int(11) NOT NULL,
  `email` text NOT NULL,
  `service` text NOT NULL,
  `service_date` date NOT NULL,
  `location_latitude` double NOT NULL,
  `location_longitude` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `two_wheeler`
--

INSERT INTO `two_wheeler` (`name`, `contact_no`, `email`, `service`, `service_date`, `location_latitude`, `location_longitude`) VALUES
('Rajvardhan', 98765, 'shinderajvardhan17@gmail.com', 'tyre', '2022-12-15', 18.5204303, 73.8567437),
('Rajvardhan', 98765, 'shinderajvardhan17@gmail.com', 'tyre', '2022-12-15', 18.5204303, 73.8567437);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(20) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_pass` varchar(50) NOT NULL,
  `user_email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `user_pass`, `user_email`) VALUES
(0, 'raj', '1234', 'shinderajvardhan17@gmail.com'),
(1, 'raj', '1234', 's@gmail.com'),
(0, 'rohan', '123', 'rohan@gmail.com'),
(0, 'abhi', '1234', 'abhi@gmail.com'),
(0, 'xyz', 'asdf', 'email4@gmail.com'),
(0, 'ro', 'rohan', 'ro@gmail.com'),
(0, 'shinde', '1234', 'sh@gmail.com'),
(0, 'my', 'abc', 'mevh@gmail.com'),
(0, 'Raj', 'lkklj', 'rajvardhanshinde45@gmail.com'),
(0, 'Rohit', '1234', 'rohit@gmail.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
