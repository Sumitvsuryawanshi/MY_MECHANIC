<?php
  $links = array(
    'js' => 'lib/waypoints/waypoints.min.js'
  );
?>
