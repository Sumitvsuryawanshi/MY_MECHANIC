
<?php

    session_start();
          $conn = mysqli_connect("localhost", "root", "","user") or die(mysqli_connect_error());
            if($_SESSION['user']){
                $user=$_SESSION['user'];
            }
            else{
                header("location:index.php");
            }
            if($_SERVER['REQUEST_METHOD']=="POST")
            {


                $name=mysqli_real_escape_string($conn,$_POST['name']);
                $contact_no=mysqli_real_escape_string($conn,$_POST['contact_no']);
                $email=mysqli_real_escape_string($conn,$_POST['email']);
                $service=mysqli_real_escape_string($conn,$_POST['service']);
                $service_date=mysqli_real_escape_string($conn,$_POST['service_date']);

                $location_latitude=mysqli_real_escape_string($conn,$_POST['location_latitude']);
                $location_longitude=mysqli_real_escape_string($conn,$_POST['location_longitude']);

                mysqli_connect("localhost", "root","","user") or die(mysqli_connect_error());

                mysqli_query($conn,"INSERT INTO two_wheeler VALUES ('$name','$contact_no','$email','$service','$service_date','$location_latitude','$location_longitude')");
                Print '<script>alert("Succesfully Added New");window.location.assign("alogin.php");</script>';

            }
            else
            {
                header("location:alogin.php");
            }
?>
