
<?php

    session_start();
          $conn = mysqli_connect("localhost", "root", "","user") or die(mysqli_connect_error());
            if($_SESSION['user']){
                $user=$_SESSION['user'];
            }
            else{
                header("location:index.php");
            }
            if($_SERVER['REQUEST_METHOD']=="POST")
            {


                $namef=mysqli_real_escape_string($conn,$_POST['namef']);
                $contact_nof=mysqli_real_escape_string($conn,$_POST['contact_nof']);
                $emailf=mysqli_real_escape_string($conn,$_POST['emailf']);
                $servicef=mysqli_real_escape_string($conn,$_POST['servicef']);
                $service_datef=mysqli_real_escape_string($conn,$_POST['service_datef']);

                $location_latitudef=mysqli_real_escape_string($conn,$_POST['location_latitudef']);
                $location_longitudef=mysqli_real_escape_string($conn,$_POST['location_longitudef']);

                mysqli_connect("localhost", "root","","user") or die(mysqli_connect_error());

                mysqli_query($conn,"INSERT INTO four_wheeler VALUES ('$namef','$contact_nof','$emailf','$servicef','$service_datef','$location_latitudef','$location_longitudef')");
                Print '<script>alert("Succesfully Added New");window.location.assign("alogin.php");</script>';

            }
            else
            {
                header("location:alogin.php");
            }
?>
