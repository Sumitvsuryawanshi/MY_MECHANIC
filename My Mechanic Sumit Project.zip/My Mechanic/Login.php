<?php
session_start();//session starts here
?>



<?php

include("Db_conection.php");

if(isset($_POST['login']))
{
    $user_email=$_POST['email'];
    $user_pass=$_POST['pass'];

    $check_user="select * from users WHERE user_email='$user_email'AND user_pass='$user_pass'";

    $run=mysqli_query($dbcon,$check_user);

    if(mysqli_num_rows($run))
    {
        echo "<script>window.open('alogin.php','_self')</script>";

        $_SESSION['email']=$user_email;//here session is used and value of $user_email store in $_SESSION.
      
    }
    else
    {
      echo "<script>alert('Email or password is incorrect!')</script>";
      echo "<script>window.open('index.php','_self')</script>";
    }
}
?>
