<?php

$dbcon=mysqli_conne ct("localhost","root","");
mysqli_select_db($dbcon,"user");
?>  
