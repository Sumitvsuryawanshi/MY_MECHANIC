<?php
   $Email = $_POST['Email'];
   $password = $_POST['password'];

   //Database Connection

   $conn = new mysqli ('localhost','root','','login');
   if($conn->connect_error)
        {
            die('connection Failed : '.$connect_error);
        }
    else
    {
        $stmt = $conn->prepare("insert into login_data(Email,password)values(?,?)");
        $stmt->bind_param("ss",$Email,$Password);
        $stmt->execute();
        echo"<script>window.open('index.html','_self')</script>";
        $stmt->close();
        $conn->close();
    }
?>
