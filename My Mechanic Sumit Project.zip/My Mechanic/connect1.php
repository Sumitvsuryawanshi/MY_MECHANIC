<?php
  $Email = $_POST['Email'];
  $Password = $_POST['Password'];

   $Re_Password = $_POST['Re_Password'];

   //Database Connection

   $conn = new mysqli ('localhost','root','','login');
   if($conn->connect_error)
        {
            die('connection Failed : '.$connect_error);
        }
    else
    {
        $stmt= $conn->prepare("insert into register_data(Eamil,Password,Re_Password)values(?,?,?)");
        $stmt->bind_param("sss",$Eamil,$Password,$Re_Password);
        $stmt->execute();
        echo"Registration  Successfully";
        $stmt->close();
        $conn->close();
    }
?>
